<?php 

session_start();

function generateSessionToken()
{
	$data['token'] = md5(uniqid(rand(), true));
	$_SESSION['token'] = $data['token'];
}
$localhost = "mysql"; 
$dbusername = "u628965060_root"; 
$dbpassword = "rootPass12";  
$dbname = "u628965060_users";  
 
$conn = mysqli_connect($localhost,$dbusername,$dbpassword,$dbname);


if( isset( $_POST[ 'submit' ] ) ) { 


    if ($_POST['token'] === $_SESSION['token'])
	{


		$IMG_NAME = $_FILES[ 'uploaded' ][ 'name' ]; 
		$IMG_EXTENSION  = substr( $IMG_NAME, strrpos( $IMG_NAME, '.' ) + 1); 
		$IMG_SIZE = $_FILES[ 'uploaded' ][ 'size' ]; 
		$IMG_TYPE = $_FILES[ 'uploaded' ][ 'type' ]; 
		$IMG_TEMPORARY  = $_FILES[ 'uploaded' ][ 'tmp_name' ]; 

		
		$target_path   = 'uploads/'; 
		$target_file   =  md5( uniqid() . $IMG_NAME ) . '.' . $IMG_EXTENSION; 
		$temp_file     = ( ( ini_get( 'upload_tmp_dir' ) == '' ) ? ( sys_get_temp_dir() ) : ( ini_get( 'upload_tmp_dir' ) ) ); 
		$temp_file    .= DIRECTORY_SEPARATOR . md5( uniqid() . $IMG_NAME ) . '.' . $IMG_EXTENSION; 

		
		
		if( ( strtolower( $IMG_EXTENSION ) == 'jpg' || strtolower( $IMG_EXTENSION ) == 'jpeg' || strtolower( $IMG_EXTENSION ) == 'png' ) && 
			( $IMG_SIZE < 200000 ) && 
			( $IMG_TYPE == 'image/jpeg' || $IMG_TYPE == 'image/png' ) && 
			getimagesize( $IMG_TEMPORARY ) ) { 
			
			
			 
			if( $IMG_TYPE == 'image/jpeg' ) { 
							
				$img = imagecreatefromjpeg( $IMG_TEMPORARY ); 
				imagejpeg( $img, $temp_file, 100); 
							} 
			else { 
				$img = imagecreatefrompng( $IMG_TEMPORARY ); 
				imagepng( $img, $temp_file, 9); 
			} 
			imagedestroy( $img ); 

	
			if( rename( $temp_file, ( getcwd() . DIRECTORY_SEPARATOR . $target_path . $target_file ) ) ) { 
		
				$target = getcwd() . DIRECTORY_SEPARATOR . $target_path . $target_file;
				$sql = "INSERT into file_upload (image_name, uploaded_on )VALUES('$target_file',  NOW())";
            
			    if(mysqli_query($conn,$sql)){
		
			        echo "File Successfully uploaded";
			    }
			
				echo "<pre><a href='${target_path}${target_file}'>${target_file}</a> succesfully uploaded!</pre>"; 
				header('location: index8.php');
				
			
			}
 
	

			if( file_exists( $temp_file ) ) 
				unlink( $temp_file ); 
		} 
		else { 
	
			echo '<pre>Your image was not uploaded. We can only accept JPEG or PNG images.</pre>'; 
		} 
    }
    else{
		die("CSRF TOKEN MATCH FAILED!...");
	}
		
	

}

generateSessionToken(); 

 
?> 
<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>CFC - Cairo Foundation Centre School</title>
<link rel="stylesheet" href='/style.css' >
	<link rel="stylesheet" href='/ds.css' >
        <link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
</head>

<body>
				<div class="formWrapper">
					<form enctype="multipart/form-data" action="" method="POST">
						<div class="inputblock">
							<h2 type="button" for="email">PLEASE UPLOAD YOUR ID</h2>
							<input name="uploaded" type="file" >
						</div>
				
					<div class="inputblock">
						<input type="hidden" name="token"  value="<?php echo $_SESSION['token']; ?>" />
						<button class="button" name="submit">Upload</button>
					</div>
				</div>
					</form>
</body>
</html>