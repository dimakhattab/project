<?php
define("DB_HOST","localhost");
define("DB_USER","root");
define("DB_PASSWORD","");
define("DB_NAME","test");
$mysqli = new mysqli(DB_HOST,DB_USER, DB_PASSWORD,DB_NAME);
?>

<?php


function clean_text($string)
{
 $string = trim($string);
 $string = stripslashes($string);
 $string = htmlspecialchars($string);
 return $string;
}


$errors= [];


if(isset($_POST["submit"]))
{
      if(empty($_POST["firstname"]))
      {
        $errors['firstname'] .= '<p><label class="text-danger">Please Enter your First Name</label></p>';
      }
      else
      {
        $Fname = clean_text($_POST["firstname"]);
        if(!preg_match("/^[a-zA-Z ]*$/", $Fname))
        {
          $errors['firstname'] .= '<p><label class="text-danger">Only letters and white space are allowed</label></p>';
        }
      }
      if(empty($_POST["MiddleName"]))
      {
        $errors['MiddleName'] .= '<p><label class="text-danger">Please Enter your Middle Name</label></p>';
      }
      else
      {
        $Mname = clean_text($_POST["MiddleName"]);
        if(!preg_match("/^[a-zA-Z ]*$/",$Mname))
        {
        $errors['MiddleName'] .= '<p><label class="text-danger">Only letters and white space are allowed</label></p>';
        }
      }

      if(empty($_POST["lastname"]))
      {
        $errors['lastname'] .= '<p><label class="text-danger">Please Enter your Last Name</label></p>';
      }
      else
      {
        $Lname = clean_text($_POST["lastname"]);
        if(!preg_match("/^[a-zA-Z ]*$/",$Lname))
        {
        $errors['lastname'] .= '<p><label class="text-danger">Only letters and white space are allowed</label></p>';
        }
      }


      if(empty($_POST["email"]))
      {
        $errors['email'] .= '<p><label class="text-danger">Please Enter your Email</label></p>';
      }
      else
      {
        $email = clean_text($_POST["email"]);
        if(!filter_var($email, FILTER_VALIDATE_EMAIL))
        {
        $errors['email'] .= '<p><label class="text-danger">Invalid email format</label></p>';
        }
      }
      if(empty($_POST["address1"]))
      {
        $errors['address1']  .= '<p><label class="text-danger">Address is required</label></p>';
      }
      else
      {
        $address1 = clean_text($_POST["address1"]);
      }
      if(!preg_match('/^(?:\\d+ [a-zA-Z ]+, ){2}[a-zA-Z ]+$/',$address1))
      {
        $errors['address1'] .='<p><label class="text-danger">Invalid address format</label></p>';
      }

      if(empty($_POST["mobilephone"]))
      {
        $errors['mobilephone'] .= '<p><label class="text-danger">Please Enter your phone number</label></p>';
    
      }
      
    
    if (count($errors) == 0) {
      require_once 'index.php';
    
  

    $sql = "INSERT INTO `ApplicationForm`(`firstname`, `MiddleName`, `lastname`, `email`,`address1`, `address2`, `homephone`, `mobilephone`, `DateOfBirth`) VALUES ('".$Fname."','".$Mname."','".$Lname."','".$email."','".$address1."','".$address2."','".$homephone."','".$mobilephone."','".$dateOfBirth."')";
		$result = $mysqli->query($sql);
		if(!$result){
			die("Couldn't enter data: ".$mysqli->error);
		}
		$mysqli->close();
		
    $stmt->bindParam('firstname', $Fname);
    $stmt->bindParam('MiddleName', $Mname);
    $stmt->bindParam('lastname', $Lname);
    $stmt->bindParam('email', $email);
    $stmt->bindParam('address1', $address1);
    $stmt->bindParam('address2', $address2);
    $stmt->bindParam('homephone', $homephone);
    $stmt->bindParam('mobilephone', $mobilephone);
    $stmt->bindParam('DateOfBirth', $dateOfBirth);



    if($stmt->execute()){
      $success = true;  
    }
  }
  }


  
  ?>


<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  
<form id="ApplicationForm" method = "POST" enctype="multipart/form-data"action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <section>
      <h2 class="form-section-title">Personal Information</h2>
      <div class="row">
        <div class="col-4">
        <p><?php echo $errors['firstname'] ?? '' ?></p>
          <label class="form-label">First Name</label>
          <input name="firstname" id="firstname" type="text" required />
        </div>
        <div class="col-4">
        <p><?php echo $errors['MiddleName'] ?? '' ?></p>
          <label class="form-label">Middle Name</label>
          <input name="MiddleName" type="text" required/>
        </div>
        <div class="col-4">
        <p><?php echo $errors['lastname'] ?? '' ?></p>
          <label class="form-label">Last Name</label>
          <input name="lastname" type="text" required/>
        </div>
      </div>
      <div class="row">
        <div class="col-7">
        <p><?php echo $errors['email'] ?? '' ?></p>
          <label class="form-label">Email</label>
          <input name="email" type="email" required />
        </div>
      </div>
      <div class="row">
        <div class="col-9">
        <p><?php echo $errors['address1'] ?? '' ?></p>
          <label class="form-label">Street Address</label>
          <input name="address1" type="text" row = "2" placeholder="15 Gordon St, 21 Cremorne, Australia" required/>
        </div>
      </div>
      <div class="row">
        <div class="col-9">
          <input name="address2" type="text" placeholder="Address Line 2"  />
        </div>
      </div>
      <div class="row">
        <div class="col-3">
          <label class="form-label">Home Phone</label>
          <input name="homephone" type="text" />
        </div>
      </div>
      <div class="row">
        <div class="col-3">
        <p><?php echo $errors['mobilephone'] ?? '' ?></p>
          <label class="form-label">Mobile Phone</label>
          <input name="mobilephone" type="text"  placeholder="+92-111-3333333" />
        </div>
      </div>
  

        <div class="col-3">
          <label class="form-label">Date of Birth</label>
          <input name="DateOfBirth" type="date" />
        </div>
      </section>
      <p> Supported File Types: ('jpg', 'gif', 'jpeg', 'png', 'pdf') </p>
      <input type="file" name="file[]" class="file" multiple required>
    <input type="submit" name="submit" value="Submit" />
  </form>
