<?php

$keyId = 'rzp_test_KcXBRQYpkWK0iC';
$keySecret = 'MGli3bBheyY0dirqOY67gimu';
$displayCurrency = 'USD';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

//Database connection details
$host = "mysql";
$username = "u628965060_root";
$password = "rootPass12";
$dbname = "u628965060_users";

//Db connection
$con = mysqli_connect($host, $username, $password, $dbname);