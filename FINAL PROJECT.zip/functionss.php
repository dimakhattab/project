<?php
function generateSessionToken()
{
	$data['_token'] = md5(uniqid(rand(), true));
	$_SESSION['_token'] = $data['_token'];
}