<?php 
    require_once 'utils.php';
    session_start();

    if(!empty($_POST['email'])) {
        if(!empty($_POST['csrf_token']) && validateToken($_POST['csrf_token'])){

            $C = connect();
            if($C) {
				$dayago = time() - 60 * 60 * 24;
				$res = sqlSelect($C, 'SELECT reg_users.id,name,COUNT(requests.id) FROM reg_users LEFT JOIN requests ON reg_users.id = user AND type=1 AND timestamp>? WHERE email=? GROUP BY reg_users.id', 'is', $dayago, $_POST['email']);
				if($res && $res->num_rows === 1) {
                    $user = $res->fetch_assoc();
                    if($user['COUNT(requests.id)'] < MAX_PASSWORD_RESET_REQUESTS_PER_DAY) {
                        $code = random_bytes(16);
                        $hash = password_hash($code, PASSWORD_DEFAULT);
						$insertID = sqlInsert($C, 'INSERT INTO requests VALUES (NULL, ?, ?, ?, 1)', 'isi', $user['id'], $hash, time());
						if($insertID !== -1) {
							$msg = '<a href="'. RESET_PASSWORD_ENDPOINT . '/' . $insertID . '/' . urlSafeEncode($code) .'">Click this link to reset password!</a>';
                            if(sendEmail($_POST['email'], $user['name'], 'Password Reset', $msg)) {
								echo 0;
							}
							else {
								echo 1;
							}
                        }
                        else{
                            echo 2;
                        }
                    }    
                    else{
                        echo 3;
                    }
                    $res->free_result();
                }
                else {
                    echo 0;
                }
                $C->close();
            }        
            else {
                echo 4;
            }
        
        
        }   
        else {
            echo 5;
        }
    }
    else {
        echo 6;
    }