<?php
    require_once 'utils.php';
    session_start();


function sendValidationEmail($email) {
$C = connect();
if($C) {
    $onedayAgo = time() - 60 * 60 * 24;
    $res = sqlSelect($C, 'SELECT reg_users.id,name,verified,COUNT(requests.id) FROM reg_users LEFT JOIN requests ON reg_users.id = requests.user AND type=0 AND timestamp>? WHERE email=? GROUP BY reg_users.id', 'is', $onedayAgo, $email);
    if($res && $res->num_rows === 1){
        $user = $res->fetch_assoc();
        if($user['verified'] === 0){
            if($user['COUNT(requests.id)'] <= MAX_EMAIL_VERIFICATION_REQUESTS_PER_DAY) {
                $verificationcode = random_bytes(16);
                $hash = password_hash($verificationcode, PASSWORD_DEFAULT);
                $requestid = sqlInsert($C, 'INSERT INTO requests VALUES (NULL, ?, ?, ?, 0)','ssi', $user['id'], $hash, time());
                if($requestid !== -1) {
                    if(sendEmail($email, $user['name'], 'Email Verification', '<a href="'. VALIDATE_EMAIL_ENDPOINT . '/' . $requestid . '/' .urlSafeEncode($verificationcode). '">Click this link to verify your email!</a>')) {
                        return 0;
                    }
                    else {
                        
                        return 1;
                    }
                }
                else {
                    
                    return 2;
                }
            }
            else {
                return 3;
            }
        }
        else {
            return 4;
        }
        $res->free_result();
    }
    else {
        return 5;
    }
    $C->close();
}
else {
    return 6;
}
return -1;
}


if(isset($_POST['validateEmail'])){
    echo sendValidationEmail($_POST['validateEmail']);
}