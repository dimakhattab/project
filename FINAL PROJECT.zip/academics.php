<?php 
	require_once 'php/utils.php'; 
	session_start();

?>

<!DOCTYPE html>
<html>
    <head>
<meta charset="utf-8">
<meta name="csrf_token" content="<?php echo createToken(); ?>" />
<title>CFC - Cairo Foundation Centre School</title>
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
    </head>

<body scroll="no" style="overflow: hidden">
    <div class="bg2">
        <div class="wrapper">
            <div class="logo">
                <img src="images/logo.png" alt="logo">
                </div>
                <ul class="nav-area">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="academics.php">Academics</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <a class="button" href="admissions.php">APPLY NOW!</a>
                    <?php if(isset($_SESSION['loggedin'])): ?>
                    <a class="button" onclick="logout(); ">logout</a>
                    <?php else: ?>
                    <a class="button" href="login.php" style="text-decoration:none">login</a>
                    <?php endif; ?>
                </ul>
            </div>	

            <div class="bottomh3">
                <!--    <img src="images/1.png" alt="Admissions Image" width="380" height="345"> -->
                    <h3>Our Education</h3>
                    <br>
                <p>The school provides a well-organized academic program from grade nine through grade twelve. At grades 11 and 12, students can choose from a variety of individual pathways to university, depending on what courses they're interested in. Our world-renowned curriculum is taught by experienced and dedicated teachers and we offer: <br> <br> - International Baccaulearette <br> <br> - American Diploma <br> <br>  The programmes on offer meet the college preparatory needs of our entire student body. This enables us to best prepare each graduate to succeed at the university of their choice. We understand our students as individuals, and motivate them accordingly through well-resourced, professional guidance.
                </p>
                <br>
                
                
        </div>
    </div>
    <div class="hmp3">
        <h1>test</h1>
    </div>
    <head>

    <script src="<?php echo dirname($_SERVER['PHP_SELF']) . 'script.js' ?>"></script>
	<div class="hidden" id="data"><?php echo htmlspecialchars(json_encode($user), ENT_QUOTES); ?></div>
	<script>
		var user = JSON.parse(document.getElementById('data').textContent);
	</script>

    </head>

</html>