<?php
$localhost = "mysql"; 
$dbusername = "u628965060_root"; 
$dbpassword = "rootPass12";  
$dbname = "u628965060_users";  
 
$conn = mysqli_connect($localhost,$dbusername,$dbpassword,$dbname);
?>