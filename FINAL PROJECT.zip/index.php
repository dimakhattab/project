<?php 
	require_once 'php/utils.php'; 
    session_start();
?>



<!DOCTYPE html>
<html>
    <head>
<meta charset="utf-8">
<title>CFC - Cairo Foundation Centre School</title>
<meta name="csrf_token" content="<?php echo createToken(); ?>" />
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
    </head>

<body>
    <div class="bg">
        <div class="wrapper">
            <div class="logo">
                <img src="images/logo.png" alt="logo">
                </div>
                <ul class="nav-area">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="academics.php">Academics</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <a class="button" href="admissions.php">APPLY NOW!</a>
                    <?php if(isset($_SESSION['loggedin'])): ?>
                    <a class="button" onclick="logout(); ">logout</a>
                    <?php else: ?>
                    <a class="button" href="login.php" style="text-decoration:none">login</a>
                    <?php endif; ?>
                </ul>
            </div>	

            <div class="welcome-text">
                <div class="centre">
                    <h1>Cairo Foundation Centre School</h1>
                </div>
                <div class="bottomh2">
                    <h2>Welcome to the CFC School website, the first of many insights on Cairo's <i>finest</i> Educational Institution.</h2>
                </div>
        </div>
    </div>

    <div class="hmp2">
        <br>
        <br>
        <br>
        <br>
        <h1>OUR MISSION STATEMENT</h1>
        <br>
        <p>Our teaching methodology emphasizes creativity, collaboration, and conceptual understanding in order to help our students develop a global perspective and knowledge of content. We work to preserve the traditions, culture, and identity of our learners, while also being open-minded and keeping a global outlook. Our campus encourages students to explore their interests and grow in their knowledge.</p>
        <br>
        <br>
        <div class="apply">
            <a href="contact.php"><br>ASK US ANYTHING</a>
        </div>
        <br>
        <br>
       <h1> OUR EDUCATION</h1>
        <br>
        <p> <br> - International Baccaulearette <br> <br> - American Diploma <br> <br> - Swedish High School Program</p>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
    </div>
    <script src="<?php echo dirname($_SERVER['PHP_SELF']) . 'script.js' ?>"></script>
	<div class="hidden" id="data"><?php echo htmlspecialchars(json_encode($user), ENT_QUOTES); ?></div>
	<script>
		var user = JSON.parse(document.getElementById('data').textContent);
	</script>


</html>