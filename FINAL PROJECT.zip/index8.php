<!doctype html>
<html lang="en">

<head>
    <title>Title</title>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


        <link rel="stylesheet" href='style.css' >
	<link rel="stylesheet" href='ds.css' >
	<link rel="preconnect" href="https://fonts.googleapis.com"> 
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
</head>
</head>
<body>
	
 <div class="bg">
        <div class="wrapper">
            <div class="logo">
                <img src="images/logo.png" alt="logo">
                </div>
                <ul class="nav-area">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="academics.php">Academics</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <a class="button" href="admissions.php">APPLY NOW!</a>
                    <?php if(isset($_SESSION['loggedin'])): ?>
                    <a class="button" onclick="logout(); ">logout</a>
                    <?php else: ?>
                    <a class="button" href="login.php" style="text-decoration:none">login</a>
                    <?php endif; ?>
                </ul>
            </div>	

    <div class="formWrapper">
        <form action="pay.php" method="post">
            <div class="inputblock">
            <h1>Application Form Fees</h1>    
            <input type="hidden" value="700" name="price"> <br><br>

                Email: <input class="form-control" type="email" name="email" id="" required> <br>
                Contact No: <input class="form-control" type="number" name="phone"><br>
                <button type="submit" class="btn" name="submit">Pay Now</button>
            </div>
        </form>
    </div>

<script src="<?php echo dirname($_SERVER['PHP_SELF']) . 'script.js' ?>"></script>
	<div class="hidden" id="data"><?php echo htmlspecialchars(json_encode($user), ENT_QUOTES); ?></div>
	<script>
		var user = JSON.parse(document.getElementById('data').textContent);
	</script>
</body>

</html>