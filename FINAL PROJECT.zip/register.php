<?php 
	require_once 'php/utils.php';
	session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="csrf_token" content="<?php echo createToken(); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Register - Secure Site</title>
	<link rel="stylesheet" href='/style.css' >
	<link rel="stylesheet" href='/ds.css' >
	<link rel="preconnect" href="https://fonts.googleapis.com"> 
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
</head>

<body>
  <div class="bg">
        <div class="wrapper">
            <div class="logo">
                <img src="images/logo.png" alt="logo">
                </div>
                <ul class="nav-area">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="academics.php">Academics</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <a class="button" href="admissions.php">APPLY NOW!</a>
                    <?php if(isset($_SESSION['loggedin'])): ?>
                    <a class="button" onclick="logout(); ">logout</a>
                    <?php else: ?>
                    <a class="button" href="login.php" style="text-decoration:none">login</a>
                    <?php endif; ?>
                </ul>
            </div>	



	
	<div class="formWrapper">
		<form id="registerForm">
			<h1>Register</h1>
			<div id="errs" class="errcontainer"></div>
			<div class="inputblock">
				<label for="name">Name</label>
				<input id="name" name="name" type="text" autocomplete="name" placeholder="Enter your name" onkeydown="if(event.key === 'Enter'){event.preventDefault();register();}" />
			</div>
			<div class="inputblock">
				<label for="email">Email</label>
				<input id="email" name="email" type="email" autocomplete="email" placeholder="Enter your email" onkeydown="if(event.key === 'Enter'){event.preventDefault();register();}" />
			</div>
			<div class="inputblock">
				<label for="password">Password</label>
				<input id="password" name="password" type="password" autocomplete="new-password" placeholder="Enter your password" onkeydown="if(event.key === 'Enter'){event.preventDefault();register();}" />
			</div>
			<div class="inputblock">
				<label for="confirm-password">Confirm Password</label>
				<input id="confirm-password" name="confirm-password" type="password" autocomplete="new-password" placeholder="Confirm your password" onkeydown="if(event.key === 'Enter'){event.preventDefault();register();}" />
			</div>
			<br>
			<div class="btn" onclick="register();">Sign Up</div>
			<br>
			<br>
			<br>
			<a href="login.php">Already have an account? Log In</a>
</form>
</div>


	<script src="<?php echo dirname($_SERVER['PHP_SELF']) . 'script.js' ?>"></script>
</body>
</html>