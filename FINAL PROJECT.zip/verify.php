<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href='/ds.css' >

<?
use PHPMailer\PHPMailer\PHPMailer;

require 'config1.php';

session_start();

require 'razorpay-php/Razorpay.php';
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$success = true;

$error = "Payment Failed";

if (empty($_POST['razorpay_payment_id']) === false) {
    $api = new Api($keyId, $keySecret);

    try
    {

        $attributes = array(
            'razorpay_order_id' => $_SESSION['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature'],
        );

        $api->utility->verifyPaymentSignature($attributes);
    } catch (SignatureVerificationError $e) {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }
}

if ($success === true) {

       
 		require_once 'Exception.php';
         require_once 'PHPMailer.php';
         require_once 'SMTP.php';
 
  $mail = new PHPMailer(true);
 
  $alert = '';

    $razorpay_order_id = $_SESSION['razorpay_order_id'];
    $razorpay_payment_id = $_POST['razorpay_payment_id'];
    $email = $_SESSION['email'];
    $price = $_SESSION['price'];

    try{
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'askcfcschools@gmail.com'; 
        $mail->Password = 'aoriepzqzscmmbyo'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = '587';
    
        $mail->setFrom('askcfcschools@gmail.com'); 
        $mail->addAddress ($email); 
    
        $mail->isHTML(true);
        $mail->Subject = 'Automatic reply:';
        $mail->Body = "<h4>Dear , <br><br> Thank you for submitting your online application.<br><br>This is to confirm that your application has been initiated and your application fees has been paid successfully. Your application is currently being reviewed by Cairo Foundation Centre Schools, you will be contacted within 3-5 working days. <br><br> Best Wishes,<br> Cairo Foundation Centre Schools";
    
        $mail->send();
        $alert = '<div class="alert-success">
                     <span>Message Sent! Thank you for contacting us.</span>
                    </div>';
      } catch (Exception $e){
        $alert = '<div class="alert-error">
                    <span>'.$e->getMessage().'</span>
                  </div>';
      }
    
  

    $razorpay_order_id = $_SESSION['razorpay_order_id'];
    $razorpay_payment_id = $_POST['razorpay_payment_id'];
    $email = $_SESSION['email'];
    $price = $_SESSION['price'];

    $sql = "INSERT INTO `orderss` (`order_id`, `razorpay_payment_id`, `price`, `status`, `email`) VALUES ('$razorpay_order_id','$razorpay_payment_id', '$price', 'success', '$email')";

    if (mysqli_query($con, $sql)) {
        echo "Payment Details  inserted to DB";
    }

    $html = "<h1>Your payment was successful</h1>
             <h2>Payment ID: {$_POST['razorpay_payment_id']}</h2>";
} else {
    $html = "<h1>Your payment failed</h1>
             <h2>{$error}</h2>";
}

echo $html;

