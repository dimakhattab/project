<?php
error_reporting(E_ALL & ~E_NOTICE);
require_once 'php/utils.php';
	if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
		header("Location: login.php");
		exit;
	}

	$user = [];	
	$C = connect();
	if($C) {
		$res = sqlSelect($C, 'SELECT * FROM reg_users WHERE id=?', 'i', $_SESSION['userID']);
		if($res && $res->num_rows === 1) {
			$user = $res->fetch_assoc();
		}
		else {
			exit;
		}
	}
	else {
		exit;
	}
?>

<?php
use PHPMailer\PHPMailer\PHPMailer;

error_reporting(E_ALL & ~E_NOTICE);

session_start();


require_once 'functionss.php';
$connection = new mysqli("mysql", "u628965060_root", "rootPass12", "u628965060_users");
?>

<?php



function clean_text($string)
{
 $string = trim($string);
 $string = stripslashes($string);
 $string = htmlspecialchars($string);
 return $string;
}

$errors= [];


if(isset($_POST["submit"]))
{
  if ($_POST['_token'] === $_SESSION['_token']){
      if(empty($_POST["firstname"]))
      {
        $errors['firstname'] .= '<p><label class="text-danger">Please Enter your First Name</label></p>';
      }
      else
      {
        $Fname = clean_text($_POST["firstname"]);
        if(!preg_match("/^[a-zA-Z ]*$/", $Fname))
        {
          $errors['firstname'] .= '<p><label class="text-danger">Only letters and white space are allowed</label></p>';
        }
      }
      if(empty($_POST["MiddleName"]))
      {
        $errors['MiddleName'] .= '<p><label class="text-danger">Please Enter your Middle Name</label></p>';
      }
      else
      {
        $Mname = clean_text($_POST["MiddleName"]);
        if(!preg_match("/^[a-zA-Z ]*$/",$Mname))
        {
        $errors['MiddleName'] .= '<p><label class="text-danger">Only letters and white space are allowed</label></p>';
        }
      }

      if(empty($_POST["lastname"]))
      {
        $errors['lastname'] .= '<p><label class="text-danger">Please Enter your Last Name</label></p>';
      }
      else
      {
        $Lname = clean_text($_POST["lastname"]);
        if(!preg_match("/^[a-zA-Z ]*$/",$Lname))
        {
        $errors['lastname'] .= '<p><label class="text-danger">Only letters and white space are allowed</label></p>';
        }
      }


      if(empty($_POST["email"]))
      {
        $errors['email'] .= '<p><label class="text-danger">Please Enter your Email</label></p>';
      }
      else
      {
        $email = clean_text($_POST["email"]);
        if(!filter_var($email, FILTER_VALIDATE_EMAIL))
        {
        $errors['email'] .= '<p><label class="text-danger">Invalid email format</label></p>';
        }
      }
      if(empty($_POST["address1"]))
      {
        $errors['address1']  .= '<p><label class="text-danger">Address is required</label></p>';
      }
      else
      {
        $address1 = clean_text($_POST["address1"]);
      }
      if(!preg_match('/^(?:\\d+ [a-zA-Z ]+, ){2}[a-zA-Z ]+$/',$address1))
      {
        $errors['address1'] .='<p><label class="text-danger">Invalid address format</label></p>';
      }
      if(empty($_POST["homephone"]))
      {
        $errors['homephone'] .= '<p><label class="text-danger">Please Enter your home number</label></p>';
    
      }
      else{
        $homephone = clean_text($_POST['homephone']);
       if(!preg_match('/^\+[0-9]{1,2}-[0-9]{3}-[0-9]{7}$/', $homephone)){
        $errors['homephone'] .= '<p><label class="text-danger">Please Enter a valid home number</label></p>';
      }
    }


      if(empty($_POST["mobilephone"]))
      {
        $errors['mobilephone'] .= '<p><label class="text-danger">Please Enter your phone number</label></p>';
    
      }
      else{
        $mobilephone = clean_text($_POST['mobilephone']);
       if(!preg_match('/^\+[0-9]{1,2}-[0-9]{3}-[0-9]{7}$/', $mobilephone)){
        $errors['mobilephone'] .= '<p><label class="text-danger">Please Enter a valid number</label></p>';
      }
    }
      $dateOfBirth = date('Y-m-d', strtotime($_POST['DateOfBirth']));
      if(empty($_POST["DateOfBirth"]))
      {
        $errors['DateOfBirth'] .= '<p><label class="text-danger">Please Enter your birth date </label></p>';
      }

    }
  else{
      $errors['_token'] = '<p><label class="text-danger">CSRF MISMATCHH!!!</label></p>';
      }
    
      
    
    if (count($errors) == 0) {


        $sql = "INSERT INTO applicationform (firstname, MiddleName, lastname, email, address1, homephone, mobilephone, DateofBirth) VALUES (?,?,?,?,?,?,?,?)";
  
        if($stmt = mysqli_prepare($connection, $sql)){
     
            mysqli_stmt_bind_param($stmt, "ssssssss", $Fname, $Mname, $Lname, $email, $address1, $homephone, $mobilephone, $dateOfBirth);
          
            $Fname = $_POST['firstname'];
            $Mname = $_POST['MiddleName'];
            $Lname = $_POST['lastname'];
            $email = $_POST['email'];
            $address1 = $_POST['address1'];
            $homephone = $_POST['homephone'];
            $mobilephone = $_POST['mobilephone'];
            $dateOfBirth = $_POST['DateOfBirth'];
        
 
            if(mysqli_stmt_execute($stmt)){
                echo "Records inserted successfully.";
                header('location: file.php');
            } else{
                echo "ERROR: Could not execute query: $sql. " . mysqli_error($connection);
            }
        } else{
            echo "ERROR: Could not prepare query: $sql. " . mysqli_error($connection);
        }

 mysqli_stmt_close($stmt);
  

 mysqli_close($connection);



  }

  
  
}

generateSessionToken();

?>
 
 
 <!DOCTYPE HTML>  
 <html>
 <head>
   
 <style>
 .error {color: #FF0000;}
 </style>

<title>CFC - Cairo Foundation Centre School</title>
<link rel="stylesheet" href='/style.css' >
	<link rel="stylesheet" href='/ds.css' >
        <link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
</head>

<body>
    <div class="bg2">
        <div class="wrapper">
            <div class="logo">
                <img src="images/logo.png" alt="logo">
                </div>
                <ul class="nav-area">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="academics.php">Academics</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <a class="button" href="admissions.php">APPLY NOW!</a>
                    <?php if(isset($_SESSION['loggedin'])): ?>
                    <a class="button" onclick="logout(); ">logout</a>
                    <?php else: ?>
                    <a class="button" href="login.php" style="text-decoration:none">login</a>
                    <?php endif; ?>
                </ul>
            </div>	
          
            <div class="formWrapper">           
      <form id="ApplicationForm" method = "POST" enctype="multipart/form-data"action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
          <section>
            <h2>Application Personal Information</h2>  
          <div class="inputblock">
              <p><?php echo $errors['firstname'] ?? '' ?></p>
                <label>First Name</label>
                <input name="firstname" id="firstname" type="text" />
              </div>
              <div class="inputblock">
              <p><?php echo $errors['MiddleName'] ?? '' ?></p>
                <label>Middle Name</label>
                <input name="MiddleName" type="text"/>
              </div>
              <div class="inputblock">
                <p><?php echo $errors['lastname'] ?? '' ?></p>
                <label>Last Name</label>
                <input name="lastname" type="text"/>
              </div>
              <div class="inputblock">
                <p><?php echo $errors['email'] ?? '' ?></p>
                <label>Email</label>
                <input name="email" type="email" />
             </div>
             <div class="inputblock">
                <p><?php echo $errors['address1'] ?? '' ?></p>
                <label>Street Address</label>
                <input name="address1" type="text" row = "2" placeholder="15 Gordon St, 21 Cremorne, Australia"/>
              </div>
              <div class="inputblock">
                <p><?php echo $errors['homephone'] ?? '' ?></p>
                <label>Home Phone</label>
                <input name="homephone" type="text" placeholder="+92-111-3333333"/>
              </div>
              <div class="inputblock">
                <p><?php echo $errors['mobilephone'] ?? '' ?></p>
                <label>Mobile Phone</label>
                <input name="mobilephone" type="text"  placeholder="+92-111-3333333"/>
            </div>
            <div class="inputblock">
              <p><?php echo $errors['DateOfBirth'] ?? '' ?></p>
                <label>Date of Birth</label>
                <input name="DateOfBirth" type="date"/>
              </div>
            
      
            </section>      
          <div class="inputblock">
            <p><?php echo $errors['_token'] ?? '' ?></p>
            <input type="hidden" name="_token"  value="<?php echo $_SESSION['_token']; ?>" />
            </div>
            
          <div class="inputblock">
            <input type="submit" name="submit" value="Submit" />
            </div>
        </form>
      
 

	<script src="<?php echo dirname($_SERVER['PHP_SELF']) . 'script.js' ?>"></script>
	<div class="hidden" id="data"><?php echo htmlspecialchars(json_encode($user), ENT_QUOTES); ?></div>
	<script>
		var user = JSON.parse(document.getElementById('data').textContent);
	</script>
