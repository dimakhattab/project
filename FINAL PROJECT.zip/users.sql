-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 04, 2022 at 04:37 AM
-- Server version: 5.7.24
-- PHP Version: 7.3.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `loginattempts`
--

CREATE TABLE `loginattempts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user` bigint(20) UNSIGNED DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `timestamp` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loginattempts`
--

INSERT INTO `loginattempts` (`id`, `user`, `ip`, `timestamp`) VALUES
(1, 18, '::1', 1650923917),
(6, 1, '::1', 1651605360),
(7, 1, '::1', 1651605362),
(8, 1, '::1', 1651605378),
(9, 9, '::1', 1651605905),
(10, 9, '::1', 1651605932),
(11, 9, '::1', 1651605932),
(12, 1, '::1', 1651606271),
(13, 1, '::1', 1651606292),
(14, 1, '::1', 1651606292),
(15, 1, '::1', 1651616955),
(16, 1, '::1', 1651616957),
(17, 1, '::1', 1651616958),
(18, 1, '::1', 1651616979),
(19, 1, '::1', 1651616980);

-- --------------------------------------------------------

--
-- Table structure for table `reg_users`
--

CREATE TABLE `reg_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reg_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user` bigint(20) UNSIGNED DEFAULT NULL,
  `hash` varchar(255) DEFAULT NULL,
  `timestamp` int(10) UNSIGNED DEFAULT NULL,
  `type` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id`, `user`, `hash`, `timestamp`, `type`) VALUES
(1, 2, '$2y$10$52OsIN7OJp8GoY22/okj1.A0BWsqnieELEcjY3EC/7IQG/9HIe0Rq', 1650373679, 0),
(2, 2, '$2y$10$DxBR7bkptLG9tjDrbmLnLOaQVxYym0.d.i3lAzdr3kb8p20uN7lgi', 1650373764, 0),
(3, 4, '$2y$10$9LTzzNjtKhl4sAdeTnAqfOqxsz6ukj228gd/VNfPwGLlbkwvMDPnu', 1650374323, 0),
(4, 2, '$2y$10$5PZiCMpLRsXz3Gc/bbksYeiTeoBez53ekZTpxL5MYQz5z3BsFoe3.', 1650374538, 0),
(5, 4, '$2y$10$7/wrgi15qxDdMBB0WyAy8.polEheT4vMJ1AsaRFH8gvXByzqvvSma', 1650374971, 0),
(6, 4, '$2y$10$5b.8/PvlJAAjrrRoNQKoEurllLZ2qMfosV7mc5WTHS6VnaDPA.4bm', 1650374975, 0),
(7, 4, '$2y$10$XneLIMO/HET4fhIUH4CUyefsLwIh7mPhBZSb1AfeiC8koBDkk8nb.', 1650374975, 0),
(8, 2, '$2y$10$FaupiWQej2uX34BjTv6PUuFl0Rub0AYScYLsC5shJyOC2xgG74xZi', 1650374983, 0),
(9, 5, '$2y$10$tFtxneqzgMFVPmfid.DQfuQk6a0ZmYUvC5MBtfGykaM9ZWpBhEwy.', 1650374995, 0),
(10, 9, '$2y$10$Reo1FsihCRySermpjdzh3e52OBMR5Or7TLHnIf4F.QLTxncegFw2C', 1650375294, 0),
(11, 9, '$2y$10$ALKBvosHW1XL5t3nDOPhn.YPaBWQHTc73RlprUqOboXPbCVbHeunq', 1650375476, 0),
(12, 9, '$2y$10$LO7PgvoCqBZ91fTkNRgfAurrj1vB7en8YhnGI557bgHHKQBdnFE3y', 1650375499, 0),
(13, 8, '$2y$10$jwiZncFne0m8zZKG22wZEeKrzn.mH0dbS4d.YYS1pNmVjSv1w2NEG', 1650375750, 0),
(14, 8, '$2y$10$GotSC63.GP11g11zJvK29uhc1uAN606sTyRWDp0cmTkKazvsY9tAa', 1650375925, 0),
(15, 8, '$2y$10$0k7JeYbwi0j5DBHW/sF/kuxBhe5LsDkaxY1kX2Xk8lwPaHyi8lD6K', 1650376319, 0),
(16, 10, '$2y$10$kErBIJwPEqEJb9izAoInnebBGZvENNtEcy7f3tfJCxLaEXv8D7pV2', 1650376697, 0),
(17, 10, '$2y$10$VpSvcUico4PWe/FyDOHKv.CU.txDMbCP9HN896J7kn5p7yYA/7jse', 1650376846, 0),
(18, 10, '$2y$10$pTrdqWjwJNSCAX5oknFRSe0e3Ch/Vj/b9aC9Cbuw9tmQ271oiqssC', 1650376934, 0),
(19, 11, '$2y$10$.mFyV8yINrjtksj5SO/HsusqvJUtUvftCquahhF9mgh5Ep4j/.k.q', 1650376966, 0),
(20, 8, '$2y$10$/L/7RIrFnplCUVXr9u66DOb1YmlqXS43.bnGc9eDRX829reY04FTi', 1650401279, 0),
(21, 9, '$2y$10$bpM6ly8Luu1LN5XKP99NoOTUg4IY8WJ.GgoAQYtC/0o0x3ns..tR.', 1650401946, 0),
(22, 12, '$2y$10$uzPRr4rQOh0lwPNujpyAiO/w8YJkLENidn./B5S7Hi53KeNd7hLGG', 1650402001, 0),
(23, 13, '$2y$10$d3yQYKV6BEP0pMIISDMBx.pXZ0Ei2qIZAtMvpBmtH6A3U4WfOnQ1i', 1650402015, 0),
(24, 14, '$2y$10$WpvQGSXXAh1LEqQ3tUleoOslK.25b.k9z7meQdlIeZBysUaPudCQ.', 1650403480, 0),
(25, 15, '$2y$10$G3QVrVP1Gcts1F5qPBnFsOKAI3ArUOoHicfw53TJ3Pohupj498UsS', 1650403842, 0),
(26, 5, '$2y$10$Oek9qu4lDMADoJL9Qd8N6.M.E8qSgZu.OmKr458TOlz4vPegkul12', 1650403950, 0),
(27, 5, '$2y$10$13CtFw7.JE9Itch5KmP3dOf.t25pepmKhc6QaQjwzfUT3fOFsxe9W', 1650404407, 0),
(28, 5, '$2y$10$EFPtJbVcKphlCnI1gmnvzuWXZc3jFDDFN0ey0EZz2JXwvgsrWLrT.', 1650404510, 0),
(29, 3, '$2y$10$5tHKzzhkvqt4CEqriv7ieuYJtnsSzmUvZGD7FH9GxM5Dg/7ZUGbti', 1650404696, 0),
(30, 16, '$2y$10$LDKTMrwQFaxJeX6mA/v5IOlJxmcWbLXaEdR4TiYO9Yzob64tPzlC6', 1650404774, 0),
(31, 17, '$2y$10$1dQ0adMG0lRvNOOHOOtL9eqwdHOMofiORpsPVm1kL2iFv1HXnpzuS', 1650404885, 0),
(32, 6, '$2y$10$mQoCDsEjxNR9AN.fjEvsleDESSSU.pbjfngg4iNjqafGfOFtqJl2m', 1650405012, 0),
(33, 6, '$2y$10$uIm4z/bcAkVY2C2/rkejBOzB9gcXZkppjbhMrxSCJc.OHHBq1dq2q', 1650405434, 0),
(34, 17, '$2y$10$jfKeaRgpUijuE1Zo4rFSt.3cSDR/dIeBbXmHqmTlryMGn66h6dHVq', 1650405526, 0),
(35, 12, '$2y$10$CW6utQIfo7rOk43v/9At0uqzf9ZC5NvCqUC5i8jyAIgsGN3v/oDbu', 1650405598, 0),
(36, 12, '$2y$10$dJUwFgFFO0jvFapL5ukik.LdY0dQe8s45XS135FXBFRoXhfowmpdu', 1650405766, 0),
(37, 12, '$2y$10$jd4kacDRn/FyLa8shhsE3OCyyu1049.CU0w2BfCQtekG0oU6dskP2', 1650406662, 0),
(38, 14, '$2y$10$pqfVju0goQkf46XYSYb1tuqcuPBMGBrE7dqTl7p4MkAzBI1ZfAA3O', 1650406795, 0),
(39, 18, '$2y$10$ZVHSbyReNom9L.K5BLNyCOHBNXVJKBAYizchQrIXaaXp.wwILetiO', 1650406887, 0),
(41, 20, '$2y$10$QGs6c6OC4aGoswtFKi/qY.DzuXARThHG3jTTsbRK6ToYTGTCWzoJi', 1650407316, 0),
(42, 21, '$2y$10$pJDiKtA8Qr.IgfPGBlx8AudeQnDt.Rf5I.JYVZWMu/YuJpk3waOqS', 1650407709, 0),
(50, 6, '$2y$10$Q.EoARRDciZlYvz/30i/Ou8G9BoZCtbcIgkOf6A6HnpDnGwxt5cVy', 1650415589, 0),
(51, 6, '$2y$10$kW5AzNE3U.YfUxKfte6a4ewueRKo.wLQL86tKlykT8uJSWZ1YbVYq', 1650415590, 0),
(52, 16, '$2y$10$onSgxFYao/p.Zfo9FQ5G1epGLFsuPREXEFXcvC6c9xB.MKijBtuXi', 1650415640, 0),
(119, 18, '$2y$10$v40zpAntD7jCPuwBWFmsauDcoFWMa7g3PuQ7nsJPX/tz5O5O6zZ9.', 1650935168, 1),
(120, 18, '$2y$10$4AV2.TmVgG3Dtc0rmsCkuOJ5HPkCMpltoK.GdvfXxCA//fRTH7.FK', 1650935171, 1),
(125, 28, '$2y$10$M0e7Yqfh2SfZWKmBn2/AdOMvRKjox79A028yv3bBpHWpAxjbZPN8i', 1651524740, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `loginattempts`
--
ALTER TABLE `loginattempts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `reg_users`
--
ALTER TABLE `reg_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `loginattempts`
--
ALTER TABLE `loginattempts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `reg_users`
--
ALTER TABLE `reg_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
