<?php


session_start();
 use PHPMailer\PHPMailer\PHPMailer;

 $connection = mysqli_connect("mysql", "u628965060_root", "rootPass12", "u628965060_users");

function alphaOnly($string){

 	if (preg_match("/^[A-Za-z-_., ]+$/", $string))
 	{
 		return true;
 	}

 	return false;

 }


 function phoneOnly($string){

 	if (preg_match("/^[0-9]*$/", $string)  && strlen($string) == 11)
 	{
 		return true;
 	}

 	return false;

 }
 function emailOnly($email_id){
    
 	if (filter_var($email_id, FILTER_VALIDATE_EMAIL)) {
 		return true;
 	} else {
 		return false;
 	}
 }


 function sanitizeString($str){

 	$str = filter_var($str, FILTER_SANITIZE_STRING);

 	$str = strip_tags($str);

 	$str = htmlspecialchars($str);

 	$str = str_replace( array( '\'', '"',
 		',' , ';', '<', '>', '*', ':', '@', '$', '(', '`', '~', ')', '[', ']', '.' ), ' ', $str);

 	return $str;
 }



 function sanitizeEmail($email){
 	$email = filter_var($email, FILTER_SANITIZE_EMAIL);

 	$email = str_replace( array( '\'', '"' , ';', '<', '>', '*', '`', '~', '[', ']' ), ' ', $email);

 	return $email;
 }

 $errors = [];
 $success = false;

 if (isset($_POST) && isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] === 'POST') {



 	extract($_POST);

 if(empty($full_name))
      {
        $errors['full_name'] = 'Please Enter your name ';
		 
 	}else{
		 if (!alphaOnly($full_name)) {
			$full_name = sanitizeString($full_name);
			$errors['full_name'] = 'Only letters and whitespaces are allowed!';
		 }
 	}


 	if (empty($mobile_number)) {
		 $errors['mobile_number'] = 'Please Enter your mobile number ';
 	}
 	else{
		if (!phoneOnly($mobile_number)){
			$mobile_number = sanitizeString($mobile_number);
			$errors['mobile_number'] = ' enter a valid mobile number ';
 	}

}

 	if (empty($email_id)) {
		$errors['email_id'] = 'Please Enter your email ';
 
 	}else{
		if (!emailOnly($email_id)) {
			$email_id = sanitizeEmail($email_id);
			$errors['email_id'] = 'Enter a valid email';
			}
 		}
	if (empty($message)) {
		$errors['message'] = 'Please Enter your message ';
	}else{
		if (!preg_match("/^[A-Za-z-_., ]+$/", $message)){
			$errors['message'] = 'Only letters and whitespaces are allowed! ';
	
			 }

	}

 	if (count($errors) == 0) {

 		require_once 'Exception.php';
		require_once 'PHPMailer.php';
		require_once 'SMTP.php';

 $mail = new PHPMailer(true);

 $alert = '';

 if (isset($_POST) && isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] === 'POST'){
   $full_name = $_POST['full_name'];
   $mobile_number = $_POST['mobile_number'];
   $email_id = $_POST['email_id'];
   $message = $_POST['message'];

   try{
     $mail->isSMTP();
     $mail->Host = 'smtp.gmail.com';
     $mail->SMTPAuth = true;
     $mail->Username = 'askcfcschools@gmail.com'; 
     $mail->Password = 'aoriepzqzscmmbyo'; 
     $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
     $mail->Port = '587';

     $mail->setFrom('askcfcschools@gmail.com'); 
     $mail->addAddress ($_POST['email_id']); 

     $mail->isHTML(true);
     $mail->Subject = 'Automatic reply:';
     $mail->Body = "<h4>Dear $full_name, <br><br> Thank you for writing to us.<br><br>We got your request and within 2 business days, we will get in touch. If your inquiry is urgent, please use the telephone number listed below to talk to one of our staff members. Otherwise, we will reply by email as soon as possible.<br><br> Best Wishes! <br>Cairo Foundation Centre School";

     $mail->send();
     $alert = '<div class="alert-success">
                  <span>Message Sent! Thank you for contacting us.</span>
                 </div>';
   } catch (Exception $e){
     $alert = '<div class="alert-error">
                 <span>'.$e->getMessage().'</span>
               </div>';
   }
 





 $sql = "INSERT INTO cf6 (full_name, mobile_number, email_id, message) VALUES (?, ?, ?, ?)";
  
 if($stmt = mysqli_prepare($connection, $sql)){

     mysqli_stmt_bind_param($stmt, "siss", $full_name, $mobile_number, $email_id, $message);
     

     $full_name = $_POST['full_name'];
     $mobile_number = $_POST['mobile_number'];
     $email_id = $_POST['email_id'];
     $message = $_POST['message'];
 
     
  
     if(mysqli_stmt_execute($stmt)){
         echo "Records inserted successfully.";
         header("location: verify2.php");
     } else{
         echo "ERROR: Could not execute query: $sql. " . mysqli_error($connection);
     }
 } else{
     echo "ERROR: Could not prepare query: $sql. " . mysqli_error($connection);
 }
 

 mysqli_stmt_close($stmt);
  

 mysqli_close($connection);
  

 		} 

	}
}
 	





 ?>

 <!DOCTYPE html>
 <html>
 <head>
 
 	<title>Submitting Secure PHP Form</title>



	 <link rel="stylesheet" href='/style.css' >
	<link rel="stylesheet" href='/ds.css' >
	<link rel="preconnect" href="https://fonts.googleapis.com"> 
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
</head>
<body>
	
<div class="bg">
        <div class="wrapper">
            <div class="logo">
                <img src="images/logo.png" alt="logo">
                </div>
                <ul class="nav-area">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="academics.php">Academics</a></li>
					<li><a href="contact.php">Contact Us</a></li>
                    <a class="button" href="admissions.php">APPLY NOW!</a>
					<?php if(isset($_SESSION['loggedin'])): ?>
  <a class="button" onclick="logout(); ">logout</a>
<?php else: ?>
  <a class="button" href="login.php" style="text-decoration:none">login</a>
<?php endif; ?>
                </ul>
            </div>
 
 </head>
 <body>

 	<div class="formWrapper">

 		<?php if($success): ?>
 			<div class="alert alert-success">
 				<p class="m-0">Form Submitted Successfully!</p>
 			</div>
 		<?php endif; ?>

 		<?php if(count($errors) > 0): ?>
 			<div class="alert alert-error">
 				<?php foreach($errors as $error): ?>
 					<p class="m-0"><?php echo $error ;?></p>
 				<?php endforeach; ?>
 			</div>
 		<?php endif; ?>

 
	<div class="inputblock">
 		<form method="POST" name="phpForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
		 <h1>Contact US</h1>
		 <br>
		 <br>
 				<input type="text" name="full_name" placeholder="Enter Full Name" value="<?php echo ($full_name && $success == false)?$full_name:'';?>" />
				<br>
 				<input type="text" name="mobile_number" placeholder="01088556336" value="<?php echo ($mobile_number && $success == false)?$mobile_number:''; ?>" />
				 <br>
 				<input type="email" name="email_id" placeholder="Enter your Email " value="<?php echo ($email_id && $success == false)?$email_id:''; ?>"/>
				 <br>
 				<input type="msg" name="message" placeholder="Enter your message" value="<?php echo ($message && $success == false)?$message:''; ?>"/>
				 <br>
				 <br>
 				<input type="submit" name="submit" />
				 <br>
				 <br>
				 <br>
				 <br>
				 <br>
				 <br>
				 <br>
				 <br>
		


 		</form>
		<svg class="wave" xmlns="http://www.w3.org/2000/svg" viewBox="0 32 1440 320"><defs><linearGradient id="a" x1="50%" x2="50%" y1="-10.959%" y2="100%"><stop stop-color="#ffffff" stop-opacity=".10" offset="0%"/><stop stop-color="#FFFFFF" stop-opacity=".05" offset="100%"/></linearGradient></defs><path fill="url(#a)" fill-opacity="1" d="M 0 320 L 48 288 C 96 256 192 192 288 160 C 384 128 480 128 576 112 C 672 96 768 64 864 48 C 960 32 1056 32 1152 32 C 1248 32 1344 32 1392 32 L 1440 32 L 1440 2000 L 1392 2000 C 1344 2000 1248 2000 1152 2000 C 1056 2000 960 2000 864 2000 C 768 2000 672 2000 576 2000 C 480 2000 384 2000 288 2000 C 192 2000 96 2000 48 2000 L 0 2000 Z"></path></svg>
		<svg class="wave" xmlns="http://www.w3.org/2000/svg" viewBox="0 32 1440 320"><defs><linearGradient id="a" x1="50%" x2="50%" y1="-10.959%" y2="100%"><stop stop-color="#ffffff" stop-opacity=".10" offset="0%"/><stop stop-color="#FFFFFF" stop-opacity=".05" offset="100%"/></linearGradient></defs><path fill="url(#a)" fill-opacity="1" d="M 0 320 L 48 288 C 96 256 192 192 288 160 C 384 128 480 128 576 112 C 672 96 768 64 864 48 C 960 32 1056 32 1152 32 C 1248 32 1344 32 1392 32 L 1440 32 L 1440 2000 L 1392 2000 C 1344 2000 1248 2000 1152 2000 C 1056 2000 960 2000 864 2000 C 768 2000 672 2000 576 2000 C 480 2000 384 2000 288 2000 C 192 2000 96 2000 48 2000 L 0 2000 Z"></path></svg>
	</div>


 	</div>

 	<script>
 		if ( window.history.replaceState ) {
 			window.history.replaceState( null, null, window.location.href );
 		}
 	</script>

<script src="<?php echo dirname($_SERVER['PHP_SELF']) . 'script.js' ?>"></script>
	<div class="hidden" id="data"><?php echo htmlspecialchars(json_encode($user), ENT_QUOTES); ?></div>
	<script>
		var user = JSON.parse(document.getElementById('data').textContent);
	</script>


 </body>
 </html> 