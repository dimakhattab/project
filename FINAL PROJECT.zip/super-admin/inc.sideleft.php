<div class="moboverlay open-left"> <a class="clsticls  open-left" id="clsticls" tabindex="1"><i class="ti-close"></i></</a> </div>
<div class="left side-menu">
  <div class="sidebar-inner slimscrollleft">
    <div id="sidebar-menu">
      <ul>
        <li><a href="index.php"><i class="ti-home"></i><span>Dashboard</span></a></li>
        <li> <a href="orders.php"><i class="fa fa-briefcase"></i><span>Order</span></a></li>
        <li> <a href="application-form.php"><i class="fa fa-envelope-o"></i><span>Application Form</span></a></li>
        <li> <a href="fileupload.php"><i class="ti-gallery"></i><span>File Upload</span></a></li> 
        <li> <a href="logout.php"><i class="fa fa-sign-out"></i><span>Logout</span></a> </li>
      </ul>
      <div class="clearfix"></div>
    </div>
    <div class="clearfix"></div>
  </div>
</div>
