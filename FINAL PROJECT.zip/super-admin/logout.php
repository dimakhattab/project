<?php  
include('../php/config.php'); 
include('inc.session-create.php'); 
session_destroy();
header('location:../login.php');
?>