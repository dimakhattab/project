<script>
var resizefunc = [];
</script>
<script src="assets/js/final.js"></script>
<script type="text/javascript" src="assets/js/bootstrap-datepicker.min.js"></script>
<script>
$(document).ready(function() {
	 $('#datatable').DataTable({});
	jQuery('.datepicker').datepicker({
				autoclose: true,
				format: "yyyy-mm-dd",
				todayHighlight: true
		});
	
	var url = window.location.pathname;
	var filename = url.substring(url.lastIndexOf('/')+1);
	var links = document.querySelectorAll('#sidebar-menu a');
	for(var i = 0; i< links.length; i++){
	var sdmenuanc = links[i].href.substring(links[i].href.lastIndexOf('/')+1);
	if(sdmenuanc==filename)
			{
				links[i].classList.add("active");
				var myElement = document.querySelector('.active');
				myElement.parentElement.parentElement.style.display='block';
			}
		}	
	
});
$('body').on('focus',".dobdatepicker", function(){
    if( $(this).hasClass('hasDatepicker') === false )  {
        $(this).datepicker({
			autoclose: true,
			format: "yyyy-mm-dd",
			todayHighlight: true,
			endDate: new Date()
    });
    }
});
</script>