<?php include('../php/config.php'); 
include('../php/utils.php'); 
include('inc.session-create.php'); 
$PageTitle="Manage FAQ";
$FileName = 'faq.php';
if($_SESSION['success']!="")
{
  $stat['success']=$_SESSION['success'];
  unset($_SESSION['success']);
}
 
?>
<!DOCTYPE html>
<html>
<head>
<?php include('inc.meta.php'); ?>
</head>
<body class="fixed-left">
<div id="wrapper">
  <?php include('inc.header.php'); ?>
    <?php include('inc.sideleft.php'); ?>
    <div class="content-page">
      <div class="content">
        <div class="container">
          <div class="row">
            <div class="col-sm-12">
              <h4 class="page-title"><?php echo $PageTitle; ?></h4>
              <ol class="breadcrumb">
                <li> <a href="<?php echo $iClassName; ?>">Home</a> </li>
                <li class="active"> <?php echo $PageTitle; ?> </li>
              </ol>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="card-box aplhanewclass">
                <div class="row">
                  <div class="col-md-9"> <?php //echo msg($stat); ?> </div>
                  <div class="col-md-3"> <a href="<?php echo $iClassName.$FileName; ?>?action=add" class="btn btn-default" style="float:right">Add New Record</a> </div>
                </div>
              </div>
              <?php if($_GET['action']=='add') { ?>
              <div class="card-box">
                <form role="form" action="" method="post" enctype="multipart/form-data">
                  <div class="row">
                    <div class="form-group clearfix col-xs-12">
                      <label class="col-lg-12 col-md-12 control-label"> Question</label>
                      <div class="col-lg-12 col-md-12">
                        <input type="text" class="form-control" name="question" value="<?php echo $_POST['question']; ?>">
                      </div>
                    </div>
                    <div class="form-group clearfix col-xs-12">
                      <label class="col-lg-12 col-md-12 control-label">Answer</label>
                      <div class="col-lg-12 col-md-12">
                        <textarea class="form-control" name="answer"><?php echo $_POST['answer']; ?></textarea>
                      </div>
                    </div>
                      <div class="form-group clearfix col-lg-12 col-md-12">
                      <label class="col-lg-12 col-md-12 control-label"> Order No.</label>
                      <div class="col-lg-12 col-md-12">
                        <input type="number" placeholder='Please enter only num' class="form-control" name="orderno" value="<?php echo $_POST['orderno']; ?>">
                      </div>
                    </div>
                     
                    <div class="form-group clearfix col-xs-12">
                      <label class="col-lg-12  col-md-12 control-label " for="confirm">Status </label>
                      <div class="col-lg-12  col-md-12">
                        <select  class="required form-control" name="status">
                          <option value="1" <?php if($_POST['status']=='1') { echo "selected"; } ?>>Active</option>
                          <option value="0" <?php if($_POST['status']=='0') { echo "selected"; } ?>>Pending</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="row" style="margin-bottom:250px;margin-top:100px;">
                    <div class="col-lg-12 col-md-12">
                      <button type="submit" name="addnewrecord" class="btn btn-default">Submit</button>
                      <a  href="<?php echo $iClassName.$FileName; ?>"  class="btn btn-default" >Back</a> </div>
                  </div>
                </form>
              </div>
            </div>
            <?php } elseif($_GET['action']=='edit') { 
	$iShowDetail=$db->getRow("select * from  faq where token='".$_GET['id']."'");
	?>
            <div class="card-box">
              <form role="form" action="" method="post" enctype="multipart/form-data">
                <div class="row">
                  <div class="form-group clearfix col-xs-12">
                    <label class="col-lg-12 col-md-12 control-label">Question</label>
                    <div class="col-lg-12 col-md-12">
                      <input type="text" class="form-control" name="question" value="<?php echo $iShowDetail['question']; ?>">
                    </div>
                  </div>
                  <div class="form-group clearfix col-xs-12">
                    <label class="col-lg-12 col-md-12 control-label">Answer</label>
                    <div class="col-lg-12 col-md-12">
                      <textarea class="form-control" name="answer"><?php echo $iShowDetail['answer']; ?></textarea>
                    </div>
                  </div>
                   <div class="form-group clearfix col-lg-12 col-md-12">
                    <label class="col-lg-12 col-md-12 control-label"> Order No.</label>
                    <div class="col-lg-12 col-md-12">
                      <input type="number" placeholder='Please enter only num' class="form-control" name="orderno" value="<?php echo $iShowDetail['orderno']; ?>">
                    </div>
                  </div>
                  <div class="form-group clearfix col-xs-12">
                    <label class="col-lg-12  col-md-12 control-label " for="confirm">Status </label>
                    <div class="col-lg-12  col-md-12">
                      <select  class="required form-control" name="status">
                        <option value="1" <?php if($iShowDetail['status']=='1') { echo "selected"; } ?>>Active</option>
                        <option value="0" <?php if($iShowDetail['status']=='0') { echo "selected"; } ?>>Pending</option>
                      </select>
                    </div>
                  </div>
                   
                </div>
                <div class="row mar-top-50">
                  <div class="col-lg-12 col-md-12">
                    <button type="submit" name="udpaterecord" class="btn btn-default">Submit</button>
                    <a  href="<?php echo $iClassName.$FileName; ?>"  class="btn btn-default" >Back</a> </div>
                </div>
                </section>
              </form>
            </div>
            <?php }   else { ?>
            <div class="card-box">
              <table id="datatable" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>S No.</th>
                    <th>Order Id</th>
                    <th>RazorPay Payment Id</th>
                    <th>Price</th>
                    <th>Email Id</th>
                    <th>Status</th>
                    
                  </tr>
                </thead>
                <tbody>
                  <?php
				  $C = connect();
				
				  $res = sqlSelect($C, 'SELECT  * from orders order by id desc');
				  $user = $res->fetch_assoc();
  				$i=0;  
				while ($iList = $res->fetch_assoc()) {$i=$i+1;  ?>
                  <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $iList['order_id']; ?></td>
                    <td><?php echo $iList['razorpay_payment_id']; ?></td>
                    <td><?php echo $iList['price']; ?></td>
                    <td><?php echo $iList['email']; ?></td>
                    <td><div class="stusact<?php echo $iList['status']; ?>"></div></td>
                     
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
    <?php include('inc.footer.php'); ?>
  </div>
</div>
<?php include('inc.js.php'); ?>
</body>
</html>
<?php exit; ?>