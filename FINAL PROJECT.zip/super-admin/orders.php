<?php include('../php/config.php'); 
include('../php/utils.php'); 
include('inc.session-create.php'); 
$PageTitle="Manage Orders";
$FileName = 'orders.php';
if($_SESSION['success']!="")
{
  $stat['success']=$_SESSION['success'];
  unset($_SESSION['success']);
}
?>
<!DOCTYPE html>
<html>
<head>
<?php include('inc.meta.php'); ?>
</head>
<body class="fixed-left">
<div id="wrapper">
<?php include('inc.header.php'); ?>
  <?php include('inc.sideleft.php'); ?>
  <div class="content-page">
    <div class="content">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <h4 class="page-title"><?php echo $PageTitle; ?></h4>
            <ol class="breadcrumb">
              <li> <a href="<?php echo $iClassName; ?>">Home</a> </li>
              <li class="active"> <?php echo $PageTitle; ?> </li>
            </ol>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card-box">
              <table id="datatable" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>S No.</th>
                    <th>Order Id</th>
                    <th>RazorPay Payment Id</th>
                    <th>Price</th>
                    <th>Email Id</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
				  $C = connect();
				
				  $res = sqlSelect($C, 'SELECT  * from orders order by id desc');
				  $user = $res->fetch_assoc();
  				$i=0;  
				while ($iList = $res->fetch_assoc()) {$i=$i+1;  ?>
                  <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $iList['order_id']; ?></td>
                    <td><?php echo $iList['razorpay_payment_id']; ?></td>
                    <td><?php echo $iList['price']; ?></td>
                    <td><?php echo $iList['email']; ?></td>
                    <td><div class="stusact<?php echo $iList['status']; ?>"></div></td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include('inc.footer.php'); ?>
  </div>
</div>
<?php include('inc.js.php'); ?>
</body>
</html>
<?php exit; ?>