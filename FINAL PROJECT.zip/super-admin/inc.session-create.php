<?php
if( is_numeric($_SESSION['userID'])!=1 || $_SESSION['loggedin']!='1' || $_SESSION['userID']=='')
	{	
		session_destroy();
		header('location:../login.php');
		exit;
 	}
?>