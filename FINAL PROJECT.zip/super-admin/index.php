<?php 
include('../php/config.php'); 
include('../php/utils.php');
include('inc.session-create.php');
if($_SESSION['success']!="")
{
   $stat['success']=$_SESSION['success'];
   unset($_SESSION['success']);
}
if($_SESSION['error']!="")
{
   $stat['error']=$_SESSION['error'];
   unset($_SESSION['error']);
}
?>
<!DOCTYPE html>
<html>
<head>
<?php include('inc.meta.php'); ?>
<style>
.dashboardpg .widget-bg-color-icon { padding-bottom: 30px; }
.dashboardpg .widget-bg-color-icon p{     float: right;
    color:#7b7b7bb3;
    font-weight: 600;
    text-shadow: 1px 1px 1px #00000026; 
	}
</style>
</head>
<body class="fixed-left">
<?php include('inc.header.php'); ?>
  <?php include('inc.sideleft.php'); ?>
  <div class="content-page dashboardpg">
    <div class="content">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <h4 class="page-title" style="margin-top: 0px;">Dashboard</h4>
            <p class="text-muted page-title-alt" style="margin: 0px;">Welcome to <?php echo $iSettingDetail['site_name']; ?> admin panel !</p>
          </div>
        </div>
 
    <?php include('inc.footer.php'); ?>
  </div>
</div>
<?php include('inc.js.php'); ?>
</body>
</html>