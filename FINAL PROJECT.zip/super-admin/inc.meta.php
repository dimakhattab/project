<title>Administrator</title>
<meta charset="UTF-8">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<link href="assets/css/final.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" type="image/png" href="../images/favicon.png"/>

<style>
.alert-error {
	color:#a94442;
	background-color:#f2dede;
	border-color:#ebccd1
}
#sidebar-menu>ul>li>a, .user-details .user-info a.dropdown-toggle, body {
	font-family:-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
	font-size:15px
}
.control-label {
	color:rgba(49, 58, 70, .73)!important;
	font-weight:600
}
.alert {
	padding:5px;
	border:1px solid transparent;
	border-radius:4px;
	margin-bottom:0
}
.alert-dismissable .close, .alert-dismissible .close {
	top:0;
	right:0
}
.sec-nav .nav>li>a {
	color:rgba(255, 255, 255, .7)!important;
	padding:0 25px
}
.sec-nav .nav>li>a.active, .sec-nav .nav>li>a:hover {
	color:#fff!important
}
.nav .open>a:focus, .sec-nav .nav .open>a, .sec-nav .nav .open>a:hover {
	background-color:#eee0;
	border-color:#337ab7
}
.sec-nav {
	border-radius:0;
	margin:0
}
.navbar-default {
	box-shadow:none;
	background:0 0!important
}
.button-menu-mobile {
	line-height:0;
	padding:12px 0;
	font-size:25px
}
.nav>li>a:hover, .sec-nav .nav>li>a:focus {
	text-decoration:none;
	background-color:#56586f08
}
.sec-nav .icon-bar {
	background:#fff
}
.content-page>.content {
	margin-top:50px
}
.navbar.sec-nav li.dropdown:hover ul.dropdown-menu {
	display:block
}
.topbar {
	background:#fff;
	box-shadow: 0px 0px 4px 1px #00000014;
}
.logo span {
    color: #051f3e;
    font-family: 'Roboto', sans-serif, arial;
    font-size: 16px;
    letter-spacing: 0px;
}
@media (max-width:767px) {
.topbar .topbar-left {
width:auto;
padding:0 0 0 20px
}
}
#bs-example-navbar-collapse-1 {
	float:right
}
.user-details {
	padding:5px 7px 12px;
	position:relative;
	background:#6377c8;
	color:#fff
}
.user-details .user-info a.dropdown-toggle {
	color:#fff
}
.user-info .text-muted {
	color:#fff
}
.logo, .nav>li>a {
	line-height:50px
}
#sidebar-menu>ul>li>a {
	color:#fff;
	display:block;
	padding:10px 0;
	margin:0 0;
	border-bottom:1px solid #5474c912
}
.maintabopen {
	background:#6279c9!important;
	color:#fff!important
}
.dropdown-divider {
	height:0;
margin:.5rem 0;
	overflow:hidden;
	border-top:1px solid #e9ecef
}
.breadcrumb {
	display:none
}
.formheading i {
	font-size:20px;
	padding:0 5px;
	color:#fff;
	background:#4e77cc
}
tr:hover {
	background-color:#f5f5f5!important;
	color:#888!important
}
.mainmsgdta {
	color:#fff;
	background:linear-gradient(to top, #8cd9ff, #59c8ff, #31bbff, #2ab8ff, #aee4ff);
	padding:1px;
	border-radius:7px
}
.shailtooltpp11 {
	cursor:pointer
}
.toptooltips {
	border:solid;
	border-color:#333 transparent;
	content:"";
	position:absolute;
	z-index:99;
	display:none;
	background:rgba(0, 0, 0, .8);
	border-radius:5px;
	color:#fff;
	right:0;
	padding:5px 15px;
	width:auto;
	height:auto;
	margin-right:45px
}
.toptooltips h5 {
	color:#fff
}
#langpair {
	border-radius:0
}
.cursorpointer {
	cursor:pointer
}
.atmdemoslcfour {
	background-color:#03a9f4;
	font-size:15px;
	color:#fff;
	padding:13px 100px;
	box-shadow:1px 1px 17px 0 #0000002b;
	margin:0 auto;
	text-align:center;
	display:table;
	background-image:linear-gradient(to bottom right, #554494, #554494);
	color:#fff!important
}
.gogmessage {
	height:105px!important;
	border-radius:0
}
.user-details .user-info a.dropdown-toggle {
	color:#fff
}
.user-info .text-muted {
	color:#fff
}
.logo, .nav>li>a {
	line-height:45px
}
#sidebar-menu ul ul ul a {
	padding-left:30px
}
#sidebar-menu ul ul a {
    padding: 10px 0px 10px 18px;
    font-size: 14px;
    color: #e0e0e0!important;
    display: block;
    position: relative;
}
.righttopmenu {
	border-top-right-radius:0;
	border-top-left-radius:0;
	padding:1px 0 0 0;
	border-top-width:0;
	width:280px
}
.righttopmenu .user-header>img {
	z-index:5;
	height:60px;
	width:60px;
	border:3px solid;
	border-color:transparent;
	border-color:rgba(255, 255, 255, .2)
}
.righttopmenu .user-header {
	padding:2px;
	text-align:center
}
.righttopmenu li.user-header {
	background-color:#5b6ec4
}
.righttopmenu label {
	display:inline-block;
	max-width:100%;
	margin-bottom:5px;
	font-weight:700
}
.righttopmenu .user-body {
	padding:15px;
	border-bottom:1px solid #f4f4f4;
	border-top:1px solid #ddd
}
.righttopmenu .user-header>p {
	z-index:5;
	color:#fff;
	color:rgba(255, 255, 255, .8);
	font-size:15px;
	line-height:1
}
.righttopmenu .user-footer {
	padding:10px 10px 10px 10px;
	margin-bottom:30px
}
.formheading {
	border-bottom:1px solid #5175caf2;
	font-size:15px;
	font-family:serif;
	padding:0 10px;
	margin:0;
	color:#fff;
	background:#4e77cc;
	text-transform:uppercase
}
.boxshadcdt {
	box-shadow:5px 5px 6px 5px #88888840;
	padding:5px 5px;
	margin:0 15px;
	min-height:400px
}
.mainmsgdta {
	color:#fff;
	background:#607d8b;
	padding:5px
}
.header-cover-mobile {
	display:none
}
.enlarged .moboverlay {
	display:none!important
}
.foot-head {
	display:none
}
.topmenuul {
	display:none!important
}
.hidden-sm-up {
	display:none
}
.side-menu.left {
background: #051f3e;
}
@media only screen and (max-width:600px) {
.navbar {
min-height:44px
}
.hidden-sm-up {
display:block
}
.topbar {
height:44px;
background-image:linear-gradient(to bottom right, #554494, #554494)!important
}
.text-center {
display:none
}
.side-menu {
display:none
}
.forced .side-menu {
display:block
}
#wrapper.enlarged .left.side-menu {
display:none!important
}
.side-menu.left {
top:0;
z-index:9999;
background: #051f3e;
overflow:scroll!important
}
#sidebar-menu ul ul a {
color:#fff!important
}
#sidebar-menu>ul>li>a {
color:#fff;
border-left:none;
padding:10px 20px
}
.side-menu {
width:300px
}
.header-cover-mobile {
display:block;
background-repeat:no-repeat;
background-position:75%;
-webkit-background-size:cover;
-moz-background-size:cover;
-o-background-size:cover;
background-size:cover;
padding-bottom:10px
}
.sidebar-image {
text-align:center;
margin:25px 0
}
.sidebar-image img {
width:80px;
height:80px;
border-radius:50%
}
.sidebar-image a {
color:#fff
}
.forced .moboverlay {
z-index:9999;
background:rgba(127, 121, 121, .8);
width:100%;
height:100%;
position:fixed;
display:block
}
.footer {
display:none
}
footer {
position:fixed;
bottom:0;
width:100%;
text-align:center;
padding-top:3px;
padding-bottom:0;
background:linear-gradient(to top, #5d6dc3, #3c86d8);
border-top:1px solid #5752527a;
color:#fff;
opacity:10;
z-index:999;
bottom:0
}
footer {
background-image:linear-gradient(-20deg, #1f6492 0, #554494 100%)
}
footer .dropdown-menu {
top:auto!important;
bottom:100%;
background-image:linear-gradient(-20deg, #1f6492 0, #554494 100%);
min-width:200px;
left:-30px
}
footer .dropdown-menu ul li a {
color:#fff
}
footer .dropdown-menu ul {
margin:0;
padding:0
}
footer .dropdown-menu ul li {
width:100%;
float:left;
display:inline;
padding:10px 10px;
font-size:15px
}
footer .foot-div-in a {
color:#f9f9f9;
font-size:13px
}
footer .foot-div-in a label {
display:block;
margin-bottom:1px
}
.foot-div-in i {
font-size:23px;
color:#fff
}
.topmenuu {
list-style-type:none;
margin:0;
padding:0;
overflow:hidden;
float:right
}
.topmenuula {
display:block;
color:#fff;
text-align:center;
padding:10px 15px;
text-decoration:none
}
.topmenuul {
float:left
}
.topmenuul {
color:#fff;
position:relative
}
.topmenuula i {
font-size:22px!important
}
.topmenuul label {
position:absolute;
top:4px;
right:5px;
background:red;
padding:5px;
width:20px;
height:20px;
line-height:10px;
border-radius:100px;
color:#fff!important;
display:inline-block;
max-width:100%;
margin-bottom:5px;
font-weight:700;
font-size:14px
}
.topmenuul {
display:block!important
}
.foot-head {
display:block
}
.content-page {
margin-left:0;
width:100%;
padding:0!important;
margin:0!important
}
#sidebar-menu ul li .menu-arrow:before {
color:#fff
}
#sidebar-menu>ul>li>a {
padding:12px 16px;
font-weight:400;
font-size:15px;
letter-spacing:.5px;
border-bottom:1px solid #b9b2b252
}

.moboverlay a {
float:right;
color:#ffff;
font-size:23px;
font-weight:bolder;
background:0 0;
border:none;
-webkit-text-stroke:2px #fff;
margin-right:25px;
margin-top:8px
}
#sidebar-menu>ul>li>a:hover {
color:#fff!important;
background-color:transparent!important
}
.slimscrollleft {
height:auto!important
}
.clsticls:focus+.side-menu {
display:none!important
}
#sidebar-menu .subdrop {
background:0 0!important;
border-left:none!important;
border-bottom:none!important
}
.sidebar-header .sidebar-image {
text-align:center;
margin:10px 0
}
.sidebar-header .sidebar-image img {
width:50px;
height:50px;
border-radius:50%;
margin-left:20px
}
.sidebar-header .sidebar-image a {
color:#fff;
position:relative;
left:5px;
font-size:20px;
font-weight:700
}
.sidebar-header .balanceshow {
width:28%;
text-align:center;
float:left;
box-shadow:0 0 26px 2px #00000033;
margin-left:4%
}
.sidebar-header {
margin-bottom:25px;
display:table;
width:100%
}
.sidebar-header .balanceshow p {
margin:4px;
font-size:14px;
color:#fff
}
.sidebar-header .mob-md-12 {
width:100%;
float:left
}
.sidebar-image col-md-12 {
width:100%;
float:left
}
.container {
padding:0;
margin:0
}
#sidebar-menu ul ul li {
margin-left:20px
}
.page-title, .text-muted {
padding-left:10px;
padding-right:10px
}
.col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-xs-1, .col-xs-10, .col-xs-11, .col-xs-12, .col-xs-2, .col-xs-3, .col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9 {
padding-left:2px;
padding-right:2px
}
.table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, .table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, .table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th {
border-top:none;
border-bottom:none
}
.table-responsive {
padding:10px
}
.enlarged #datatable_wrapper {
overflow-x:unset;
margin-bottom:25px
}
.dataTables_length {
display:none
}
.table-responsive::-webkit-scrollbar-track {
-webkit-box-shadow:inset 0 0 6px rgba(0, 0, 0, .3);
border-radius:10px!important;
background-color:#f5f5f5
}
.table-responsive::-webkit-scrollbar {
width:20px!important;
background-image:linear-gradient(-20deg, #1f6492 0, #554494 100%);
height:12px
}
.table-responsive::-webkit-scrollbar-thumb {
border-radius:10px!important;
-webkit-box-shadow:inset 0 0 6px rgba(0, 0, 0, .3);
background-image:linear-gradient(-20deg, #1f6492 0, #554494 100%)
}
.activvate {
background-color:transparent!important
}
.googlemsg textarea {
border-radius:0
}
.mainmsgdta {
border-radius:0
}
#showerror {
width:100%
}
}
.pagcursorpointer a {
	cursor:pointer
}
@keyframes placeHolderShimmer {
0% {
background-position:-468px 0
}
100% {
background-position:468px 0
}
}
.animated-background {
	animation-duration:1s;
	animation-fill-mode:forwards;
	animation-iteration-count:infinite;
	animation-name:placeHolderShimmer;
	animation-timing-function:linear;
	background:#f6f7f8;
	background:linear-gradient(to right, #eee 8%, #ddd 18%, #eee 33%);
	background-size:800px 104px;
	height:30px;
	position:relative;
	margin-bottom:20px;
	margin-top:20px
}
.mar-top-50 {
	margin-top:50px;
}
.stusact1:after {
	content: "Active";
}
.stusact1 {
	width: 60px;
	background: #8bc34a;
	color:#fff;
	text-align: center;
	padding: 2px 0px;
	font-size: 14px;
}
.stusact0:after {
	content: "Inactive";
}
.stusact0 {
	width: 60px;
	background: #FF5722;
	color:#fff;
	text-align: center;
	padding: 2px 0px;
	font-size: 14px;
}
.radiobtnsze {
	width: 20px;
	height: 20px;
	position: relative;
	top: 5px;
}
#sidebar-menu>ul>li>a.active {
	color:#fdc500!important;
	
}
#sidebar-menu ul li a i {
    font-size: 15px;
    color: #fdc500;
}#sidebar-menu ul li .menu-arrow:before { color:#fff; }
</style>
