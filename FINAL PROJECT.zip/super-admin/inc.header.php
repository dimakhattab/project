<div id="wrapper">
<div class="topbar">
  <div class="topbar-left">
    <div class="text-center"> <a href="dashboard.php" class="logo"> <i class="icon-magnet icon-c-logo"></i> <span>Admin Panel</span> </a> </div>
  </div>
  <div class="navbar navbar-default" role="navigation">
    <div class="container">
      <div class="">
        <div class="pull-left">
          <button class="button-menu-mobile open-left"> <i style="color:#fff;" class="fa fa-bars"></i> </button>
          <span class="clearfix"></span> </div>
        <ul class="nav navbar-nav navbar-right pull-right">
           
         <!-- <li class="dropdown hidden-xs"> <a href="support.php" > <i class="fa fa-bell-o"></i> <span class="badge badge-xs badge-danger">0</span> </a> </li>
          <li class="hidden-xs"> <a href="settings.php" class=" waves-effect waves-light"><i class="fa fa-cogs"></i></a> </li>
           <li class="dropdown"> <a class="dropdown-toggle profile" data-toggle="dropdown" aria-expanded="true"> <img src="../uploads/no-img.png" style="border:none!important;"> </a>
            <ul class="dropdown-menu">
              <li><a href="login_profile.php"><i class="ti-user m-r-5"></i> Update Profile</a></li>
              <li><a href="login_pass.php"><i class="ti-user m-r-5"></i>Change Password</a></li>
              <li><a href="logout.php"><i class="ti-power-off m-r-5"></i> Logout</a></li>
            </ul>
          </li>
           -->
        </ul>
      </div>
    </div>
  </div>
</div>
