<?php
echo '		<link rel="stylesheet" href="css/style.css" >
<link rel="stylesheet" href="css/ds.css" >
<link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
<div class="bg">
           <div class="wrapper">
               <div class="logo">
                   <img src="images/logo.png" alt="logo">
                   </div>
                   <ul  class= "nav-area">
                       <li><a href="index.php">Home</a></li>
                    </ul>
       <div class="formWrapper">
       <h2>Message Sent! Thank you for contacting us.</h2>
       </div>'
       ;
?>