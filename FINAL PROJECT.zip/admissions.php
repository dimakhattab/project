<?php 
	require_once 'php/utils.php'; 
	session_start();

?>

<!DOCTYPE html>
<html>
    <head>
<meta charset="utf-8">
<meta name="csrf_token" content="<?php echo createToken(); ?>" />
<title>CFC - Cairo Foundation Centre School</title>
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800&display=swap" rel="stylesheet">
    </head>

<body scroll="no" style="overflow: hidden">
    <div class="bg3">
        <div class="wrapper">
            <div class="logo">
                <img src="images/logo.png" alt="logo">
                </div>
                <ul class="nav-area">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="academics.php">Academics</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <?php if(isset($_SESSION['loggedin'])): ?>
                    <a class="button" onclick="logout(); ">logout</a>
                    <?php else: ?>
                    <a class="button" href="login.php" style="text-decoration:none">login</a>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="bottomh3">
                <!--    <img src="images/1.png" alt="Admissions Image" width="380" height="345"> -->
                    <h3>Required Documents</h3>
                    <br>
                <p>Applicants must include the following documents <br> in order to ensure a successful admission process: 
                    <br>
                    <br>
                    <ul>
                        <li>Click on the "Apply Here" Button</li>
                        <br>
                        <li>Login/Register to the Website</li>
                        <br>
                        <li>Submit the Necessary Information</li>
                        <br>
                        <li>Pay the Required Amount</li>
                    </ul>
                
                </p>
            </div>
            <div class="welcome-text">
                    <a class="centre" href="application.php">APPLY HERE </a>
            </div>
            
                
        </div>
    </div>
    <div class="hmp3">
        <h1>test</h1>
    </div>
    <script src="<?php echo dirname($_SERVER['PHP_SELF']) . 'script.js' ?>"></script>
	<div class="hidden" id="data"><?php echo htmlspecialchars(json_encode($user), ENT_QUOTES); ?></div>
	<script>
		var user = JSON.parse(document.getElementById('data').textContent);
	</script>


</html>