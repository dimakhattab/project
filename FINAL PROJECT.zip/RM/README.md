## Razorpay Payment Gateway Integration in PHP With Db Integration

## Installing

- Clone this repo
- Edit config.php file there add your Razorpay keyId, keySecret and mysqli Database credential
